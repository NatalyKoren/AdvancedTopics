//
// Created by DELL on 04/04/2018.
//
#include <iostream>
#include "GamePlayed.h"
//#include "main_tests.h" //todo remove this
int main(){
    // std::cout << "main!" << std::endl;
    //if(tests() != 0)
     //   std::cout << "faid tests!" << std::endl;
    Game newGame;
    newGame.startGame();
    return 0;
}
