Our program treats empty lines within the input files as the end of the file. This is compliant with Dr. Kirsh's message in the forum: http://moodle.tau.ac.il/mod/forum/discuss.php?d=50257

After parsing the position files:

1. If there are no moving pieces for both players: Tie. Reason: All moving PIECEs of the opponent  are eaten.

2. If there are no moving pieces for player 2: Player 1 wins. Reason: All moving PIECEs of the opponent are eaten. http://moodle.tau.ac.il/mod/forum/discuss.php?d=50442&parent=73845

3. If a moves file does not exist the player simply does not play.

4. If both moving files doesn't exist, the game finishes after the positioning files ended. http://moodle.tau.ac.il/mod/forum/discuss.php?d=50217
